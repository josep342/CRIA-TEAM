from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.graphics.vertex_instructions import RoundedRectangle
from kivy.metrics import *
from kivy.graphics import *
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.textfield import MDTextField
from kivy.uix.popup import Popup
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivymd.uix.datatables import MDDataTable

Builder.load_file('screenmananger.kv')

class Myscreenmananger(MDScreenManager):
    
    pass

class EcolAppApp(MDApp):

    def build(self):

        global etatmenu,pagecurrent,cadresetting1,tabsection,btrengistrersection,tintitulesection,tidsection,titresection

        global tidoption,tintituleoption,btrengistrer,taboption,titreann,tidanne,tintituleanne,btrengistreranne,tabanne
        global cadresettingpaiemnt,cadresettinguser

        pagecurrent='accueilPage'

        etatmenu=0

        self.theme_cls.primary_palette = "Orange"
        #self.theme_cls.theme_style = "Dark"

        # outils de la page setting inscription


        cadresetting1=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        
        labpdateclss=Label(text="Update",bold=True,color='black',pos_hint={'x':.85,'y':.93},size_hint=(.1,.07),font_size='12sp')

        cadrebtactivUpdate=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.95,'y':.93}  
                                                                                                           
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
        
''')
        btactivUpdate=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x':.5, 'center_y':.5}
    color_active:'red'
    active:False
    #icon_inactive:'close'
    #icon_inactive_color: "grey"
    #on_active:app.activer(self)

''')
        
        titreoption=Label(text="Option",bold=True,color='black',pos_hint={'x':.15,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidoption=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintituleoption=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrer=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.84}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        taboption=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':0.52},check=True,rows_num=2000,use_pagination=True)
        
        
        titreclass=Label(text="Classe",bold=True,color='black',pos_hint={'x':.15,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidclass=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituleclass=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrerclass=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.35}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        tabclass=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':.02},check=True,rows_num=2000,use_pagination=True)

        #tabtrafic.bind(on_check_press=self.check_rdv)

        titresection=Label(text="Section",bold=True,color='black',pos_hint={'x':.68,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidsection=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintitulesection=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrersection=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.84}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''') 
        
        tabsection=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.52},check=True,rows_num=2000,use_pagination=True)

        titreann=Label(text="Edition Scolaire",bold=True,color='black',pos_hint={'x':.68,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidanne=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituleanne=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistreranne=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.35}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''') 
        
        tabanne=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.02},check=True,rows_num=2000,use_pagination=True)

        try:
            cadrebtactivUpdate.add_widget(btactivUpdate)
        except:
            pass
    
        try:
            cadresetting1.add_widget(labpdateclss)
            cadresetting1.add_widget(cadrebtactivUpdate)
            cadresetting1.add_widget(titreoption)
            cadresetting1.add_widget(tidoption)
            cadresetting1.add_widget(tintituleoption)
            cadresetting1.add_widget(btrengistrer)
            cadresetting1.add_widget(taboption)

            cadresetting1.add_widget(tabsection)
            cadresetting1.add_widget(btrengistrersection)
            cadresetting1.add_widget(tintitulesection)
            cadresetting1.add_widget(tidsection)
            cadresetting1.add_widget(titresection)

            
            cadresetting1.add_widget(tabclass)
            cadresetting1.add_widget(titreclass)
            cadresetting1.add_widget(tidclass)
            cadresetting1.add_widget(tintituleclass)
            cadresetting1.add_widget(btrengistrerclass)

            cadresetting1.add_widget(titreann)
            cadresetting1.add_widget(tidanne)
            cadresetting1.add_widget(tintituleanne)
            cadresetting1.add_widget(btrengistreranne)
            cadresetting1.add_widget(tabanne)
        except:
            pass

        cadresettingpaiemnt=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        
        
        titremotif=Label(text="Motif",bold=True,color='black',pos_hint={'x':.15,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidmotif=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintitulemotif=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrermotif=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.84}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        tabmotif=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':0.52},check=True,rows_num=2000,use_pagination=True)
        
        titredevise=Label(text="Devise",bold=True,color='black',pos_hint={'x':.68,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tiddevise=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintituledevise=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrerdevise=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.84}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''') 
        
        tabdevise=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.52},check=True,rows_num=2000,use_pagination=True)


        titretranche=Label(text="Tranche",bold=True,color='black',pos_hint={'x':.15,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidtranche=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituletranche=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrertrache=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.35}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        tabtranche=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':.02},check=True,rows_num=2000,use_pagination=True)

        try:
            cadresettingpaiemnt.add_widget(tabtranche)
            cadresettingpaiemnt.add_widget(btrengistrertrache)
            cadresettingpaiemnt.add_widget(tintituletranche)
            cadresettingpaiemnt.add_widget(tidtranche)
            cadresettingpaiemnt.add_widget(titretranche)
        
        except:
            pass

        try:
            cadresettingpaiemnt.add_widget(tabdevise)
            cadresettingpaiemnt.add_widget(btrengistrerdevise)
            cadresettingpaiemnt.add_widget(tintituledevise)
            cadresettingpaiemnt.add_widget(tiddevise)
            cadresettingpaiemnt.add_widget(titredevise)
        
        except:
            pass
        try:
            cadresettingpaiemnt.add_widget(titremotif)
            cadresettingpaiemnt.add_widget(tidmotif)
            cadresettingpaiemnt.add_widget(tintitulemotif)
            cadresettingpaiemnt.add_widget(btrengistrermotif)
            cadresettingpaiemnt.add_widget(tabmotif)
        
        except:
            pass
        

        cadresettinguser=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        
        titreuser=Label(text="Users",bold=True,color='black',pos_hint={'center_x':.5,'y':.9},size_hint=(.3,.12),font_size='22sp')
    
        labchangemode=Label(text="Update",bold=True,color='black',pos_hint={'x':.8,'y':.93},size_hint=(.1,.07),font_size='12sp')
        
        cadresuitchmode=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.9,'y':.935}  
                                                                                                           
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
        
''')
        suitchmode=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    active:False
''')

        tiduser=MDTextField(hint_text='Identifiant',font_size='20sp',bold=True,line_color_normal="black",icon_right="qrcode",pos_hint={'x':.025,'y':.83},size_hint=(.2,.08),text_color_normal='black')
        tnomunser=MDTextField(hint_text='Nom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.275,'y':.83},size_hint=(.2,.1),text_color_normal='black')
        tpostnomuser=MDTextField(hint_text='Postnom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.525,'y':.83},size_hint=(.2,.08),text_color_normal='black')
        tprenomuser=MDTextField(hint_text='Prenom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.775,'y':.83},size_hint=(.2,.1),text_color_normal='black')
        
        tadressuser=MDTextField(hint_text='Adresse',font_size='20sp',bold=True,line_color_normal="black",icon_right="home",pos_hint={'x':.025,'y':.73},size_hint=(.2,.1),text_color_normal='black')
        tphonuser=MDTextField(hint_text='Phone',icon_right='phone',font_size='20sp',line_color_normal='black',pos_hint={'x':.275,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        tgmailuser=MDTextField(hint_text='E-mail',font_size='20sp',bold=True,line_color_normal="black",icon_right="gmail",pos_hint={'x':.525,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        tpwduser=MDTextField(hint_text='Pwd',icon_right='eye',font_size='20sp',line_color_normal='black',pos_hint={'x':.775,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        
        tintituleclass=MDTextField(hint_text='',font_size='20sp',bold=True,line_color_normal="black",icon_right="gmail",pos_hint={'x':.65,'y':.6},size_hint=(.2,.08),text_color_normal='black')
        
        labfontion=Label(text="Fonction",color='black',pos_hint={'x':.025,'y':.61},size_hint=(.1,.1))
        
        fonctionuser=Builder.load_string('''
Spinner:
    text:"Choisir"
    bold:True
    pos_hint:{'x':.13,'y':.63}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    color:'black'                                                       
                                                                
    canvas.before:
        Color:
            rgb:255/255,128/255,0/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')

        lablph=Label(text="Photo",color='black',pos_hint={'x':.3,'y':.61},size_hint=(.1,.1))

        photonuser=Builder.load_string('''
Spinner:
    text:"Importer fichier"
    color:'black'
    bold:True
    pos_hint:{'x':.45,'y':.63}
    size_hint:.2,.04
    background_color:[0,0,0,0]
                                         
    canvas.before:
        Color:
            rgb:255/255,128/255,0/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')

        btrengistreruser=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.7,'y':0.63}
    size_hint:(0.2,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        tabuser=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NOM",dp(35)),
            ("POSTNOM ",dp(35)),
            ("PRENOM",dp(35)),
            ("ADRESSE",dp(40)),
            ("PHONE",dp(35)),
            ("PHOTO",dp(35)),
            ("FONCTION",dp(35)),
            ("E-MAIL ",dp(35)),
            ("PWD",dp(35))
            ], row_data=[],size_hint=(0.95,0.54),pos_hint={'x':0.025,'y':0.025},check=True,rows_num=2000,use_pagination=True)
        
        
        try:
            
            cadresuitchmode.add_widget(suitchmode)
            cadresettinguser.add_widget(cadresuitchmode)
            cadresettinguser.add_widget(labchangemode)
        except:
            pass


        try:
            cadresettinguser.add_widget(tabuser)
            cadresettinguser.add_widget(btrengistreruser)
            cadresettinguser.add_widget(photonuser)
            cadresettinguser.add_widget(lablph)
            cadresettinguser.add_widget(fonctionuser)
            cadresettinguser.add_widget(labfontion)
        except:
            pass

        try:
            cadresettinguser.add_widget(titreuser)
            cadresettinguser.add_widget(tpwduser)
            cadresettinguser.add_widget(tgmailuser)
            cadresettinguser.add_widget(tphonuser)
            cadresettinguser.add_widget(tadressuser)
            cadresettinguser.add_widget(tprenomuser)  
            cadresettinguser.add_widget(tpostnomuser)

            cadresettinguser.add_widget(tnomunser)
            cadresettinguser.add_widget(tiduser)
        except:
            pass

            
        return Myscreenmananger()

    def ajoutfP_inscription(self,instance):

        self.root.ids.btnsave.text="[b]Enregistrer[/b]"
    
    def modifierfP_inscription(self,instance):
        global msginforeab

        self.root.ids.btnsave.text="[b]Modifier[/b]"

        #=Button(text="ok")

        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''

MDChip:
    background_color:[0,0,0,0]
    text:"[b]Close[/b]"
    markup:True
    pos_hint:{'x':0.6, 'y':.05}
    size_hint:(0.3,0.12)
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True
    

    #on_release:app.updateinfoperson(self) 

    MDIcon:
        icon:"close-box"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'  
    #on_release:app.fermerclossettinf(self)
                                                
   
''')
        btvalquestion2.bind(on_release=lambda x:msginforeab.dismiss())

        trech=MDTextField(hint_text='Rechercher par ID',pos_hint={'x':.05,'center_y':.6},size_hint=(.4,.15),line_color_normal='black')
        
        comborech=Builder.load_string('''

Spinner:
    text:"Choisir"
    color:'black'
    font_size:'15sp'
    pos_hint:{'x':.5,'center_y': .6}
    size_hint:.45,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:255/255,128/255,0/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]


''')
        try:
            cad.add_widget(btvalquestion2)
            cad.add_widget(trech)
            cad.add_widget(comborech)
        except:
            pass


        msginforeab=Popup(title='RECHERCHE',content=cad,size_hint=(.4,.5))
        msginforeab.open()


    def comparesecurite(self,instance):

        self.root.current='accueilPage'

    def on_start(self):

        try:
            #self.root.ids.cadregauche.parent.remove_widget(self.root.ids.cadregauche)
            etatmenu=1
        except:
            pass

    def accueilPagef(self,instance):
        global pagecurrent

        pagecurrent='accueilPage'

        self.root.current='accueilPage'

    def settingPagef(self,instance):

        self.root.current='settingPage'

        try:
            self.root.ids.settingPage.add_widget(cadresetting1)
        except:
            pass
    
    def settingPageinscription(self, instance):

        try:
            self.root.ids.settingPage.add_widget(cadresetting1)
        except:
            pass

        try:
            self.root.ids.settingPage.remove_widget(cadresettingpaiemnt)
        except:
            pass
        try:
            self.root.ids.settingPage.remove_widget(cadresettinguser)
        except:
            pass

    def settingPagepaiement(self,instance):

        try:
            self.root.ids.settingPage.remove_widget(cadresettinguser)
        except:
            pass

        try:
            self.root.ids.settingPage.remove_widget(cadresetting1)
        except:
            pass

        try:
            self.root.ids.settingPage.add_widget(cadresettingpaiemnt)
        except:
            pass

    def settingPageUser(self,instance):

        try:
            self.root.ids.settingPage.remove_widget(cadresetting1)
        except:
            pass

        try:
            self.root.ids.settingPage.remove_widget(cadresettingpaiemnt)
        except:
            pass

        try:
            self.root.ids.settingPage.add_widget(cadresettinguser)
        except:
            pass

        

    def inscriptionPagef(self,instance): 
        global pagecurrent

        pagecurrent='inscriptionPage'

        try:
            self.root.current="inscriptionPage"
        except:
            pass

    # valider soimeme 

    def inscriptionPagefclean(self,instance):

        self.root.ids.cadregauche.parent.remove_widget(self.root.ids.cadregauche)


    def accueilPagefclean(self,instance):

        self.root.ids.cadregauche.parent.remove_widget(self.root.ids.cadregauche)

    def changever2(self,instance):

        global etatmenu,pagecurrent

        self.root.ids.cadregauche.size_hint=(0.3,0.83)

        if etatmenu==0:

            try:
                self.root.ids.cadregauche.parent.remove_widget(self.root.ids.cadregauche)
            except:
                pass

            etatmenu=1
           
        elif etatmenu==1:

            etatmenu=0

            try:

                if pagecurrent=="accueilPage":

                    self.root.ids.accueilPage.add_widget(self.root.ids.cadregauche)

                elif pagecurrent=='inscriptionPage':
                    
                    self.root.ids.inscriptionPage.add_widget(self.root.ids.cadregauche)
            except:
                pass
                    
            

    
    def affmenugacuhe(self,instance):

        pass
    
    def affmenu(self, instance):
        pass
    

if __name__=="__main__":

    EcolAppApp().run()