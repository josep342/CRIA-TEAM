from kivy.lang import Builder
from kivy.metrics import dp
from kivymd.app import MDApp
from kivymd.uix.datatables import MDDataTable

KV = ''''
BoxLayout:
    orientation: 'vertical'

    MDToolbar:
        title: "MDDataTable with Pagination"

    ScrollView:
        MDDataTable:
            id: data_table
            use_pagination: True
            pagination_menu_height: "240dp"
            pagination_menu_pos: 'center'
            column_data: [
                ("Column 1", dp(30)),
                ("Column 2", dp(30)),
                ("Column 3", dp(30)),
            ]
            row_data: [
                ("Data 1", "Data 2", "Data 3"),
                # Add more rows here
            ]
''''

class MainApp(MDApp):
    def build(self):
        return Builder.load_string(KV)

    def on_start(self):
        # You can also dynamically add rows to the MDDataTable
        data_table = self.root.ids.data_table
        for i in range(50):  # Add 50 rows for demonstration
            data_table.row_data.append(("Data " + str(i+1), "Data " + str(i+2), "Data " + str(i+3)))

MainApp().run()