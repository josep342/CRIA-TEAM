import kivy
import kivymd
from kivymd.app import MDApp
from kivy.core.window import Window
from kivymd.uix.floatlayout import MDFloatLayout
from kivy.uix.label import Label 
from kivy.uix.button import Button
from kivymd.uix.datatables import MDDataTable
from kivy.uix.image import Image
from kivy.uix.textinput import TextInput
import os
import shutil
from kivy.uix.popup import Popup
import psutil
import pandas as pd
import mysql.connector
from datetime import datetime


from kivy.metrics import dp

Window.size=(700,600)


class Importeur(MDApp):
    
    def build(self):

        global parco,labchemin,textparcourir,i,j,lign,listiderror,listnomeror,err,listpuerror

        listiderror=[]
        listnomeror=[]
        listpuerror=[]

        
        lign=0
        err=0
        
        i=0
        j=0

        cadre0=MDFloatLayout()

        tabl=MDDataTable(column_data=[],size_hint=(0.9,0.06),pos_hint={'center_x':0.5,'y':0.9})
        #tabl.bind(on_check_press=self.affitravail)

        #img=Image(source="mon logoo.png",size_hint=(0.1,0.1),pos_hint={'x':0,'y':0})

        lab1=Label(text='[b]IMPORTATEUR EXCEL -> PYTHON[/b]',color='gray',pos_hint={'center_x':0.5,'center_y':0.5}, size_hint=(0.9,0.9), font_size='30sp',markup=True)

        labparcourir=Label(text='[b]Chemin (*.xlsx)[/b]',color='black',pos_hint={'x':0.4,'y':0.8}, size_hint=(0.15,0.06), font_size='13sp',markup=True)
        textparcourir=TextInput(pos_hint={'x':0.6,'y':0.8}, size_hint=(0.35,0.051), font_size='15sp')
        
        labchemin=TextInput(text='100',pos_hint={'x':0.2,'y':0.6}, size_hint=(0.8,0.05), font_size='12sp')


        btchek=Button(text='[b]Checker[/b]',color='white',background_color='seagreen',pos_hint={'x':0.05,'y':0.7}, size_hint=(0.25,0.06), font_size='20sp',markup=True)
        btchek.bind(on_release=self.checking)

        btsegm=Button(text='[b]Corriger[/b]',color='white',background_color='seagreen',pos_hint={'x':0.36,'y':0.7}, size_hint=(0.25,0.06), font_size='20sp',markup=True)
        btsegm.bind(on_release=self.error)

        btimporter=Button(text='[b]Importer[/b]',color='white',background_color='seagreen',pos_hint={'x':0.67,'y':0.7}, size_hint=(0.25,0.06), font_size='20sp',markup=True)
        btimporter.bind(on_release=self.parcourir)

        tablbas=MDDataTable(column_data=[],size_hint=(0.9,0.06),pos_hint={'center_x':0.5,'y':0.5})

        labdetail=Label(text='[b]DETAIL[/b]',color='gray',pos_hint={'center_x':0.5,'center_y':0.5}, size_hint=(0.9,0.9), font_size='30sp',markup=True)

        try:
            cadre0.add_widget(labchemin)
        except:
            pass

        try:
            pass
            #cadre0.add_widget(img)
        except:
            pass

        try:
            cadre0.add_widget(btchek)
        except:
            pass
        try:
            cadre0.add_widget(btsegm)
        except:
            pass

        try:
            cadre0.add_widget(btimporter)
        except:
            pass

        try:
            tablbas.add_widget(labdetail)
        except:
            pass

        try:
            cadre0.add_widget(tablbas)
        except:
            pass

        try:
            cadre0.add_widget(labparcourir)
        except:
            pass
        try:
            cadre0.add_widget(textparcourir)
        except:
            pass

        try:
            tabl.add_widget(lab1)
        except:
            pass

        try:
            cadre0.add_widget(tabl)
        except:
            pass

        
        return cadre0

    def checking(self,instance):
        global listiderror,listnomeror,listpuerror

        print("LISTE ECHOUE")

        i=0

        for i in range(len(listiderror)-1):

            print(listiderror[i]," - ",listnomeror[i]," - ",listpuerror[i])

        cad=MDFloatLayout()

        labdetail=Label(text='[b]ERROR [/b]'+str(len(listiderror)),color='gray',pos_hint={'center_x':0.5,'center_y':0.5}, size_hint=(0.9,0.9), font_size='30sp',markup=True)

        try:
            cad.add_widget(labdetail)
        except:
            pass

        msg=Popup(title="STATUT CONNEXION",content=cad,size_hint=(None, None), size=(400,200))
        msg.open()

    def cconnexion(self):
        global con
        try:
            con=mysql.connector.connect(
            host="localhost",
            user="askyas",
            password="askyas",
            database="pharma"
            )
            return con
        except:
            msg=Popup(title="STATUT CONNEXION",content=Button(text='Erreur survenue lors de la connexion au serveur'),size_hint=(None, None), size=(400,200))
            msg.open()

    def error(self,instance):
        global listiderror,listnomeror,listpuerror,err,rater
        
        listidnew=[]
        listnomnew=[]

        i=0
        
        datt=datetime.now().strftime('%Y-%m-%d')
       
        for i in range(len(listiderror)-1):

            mat=str(listiderror[i-1])
            nom=str(listnomeror[i-1])
            puu=float(listpuerror[i-1])

            try:
                self.cconnexion()
                cursor=con.cursor()
                query="insert into produit(matricule,nom,categorie,anti,traite,posologie,age_utilisation,pu,stock,dats,stock_p) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                datat=(mat,nom,"","","","","",puu,0,datt,0)
                cursor.execute(query,datat) 
                con.commit()
                cursor.close()
                con.close()

                rater -=1

                listiderror.pop(i)
                listnomeror.pop(i)
                listpuerror.pop(i)

            except:
                pass
        
        msg=Popup(title="RAPPORT",content=Button(text=' Total produit recupéré avec succes'), size_hint=(None, None), size=(400,200))
        msg.open()
        
    def parcourir(self,instance):
        global i,j,lign,listiderror,listnomeror,listpuerror,rater

        listiderror=[]
        listnomeror=[]
        listpuerror=[]

        df=pd.read_excel('Liste.xlsx')

        tableau=df.to_numpy()

        lign=df.shape[0]

        i=0

        rater=0
        datt=datetime.now().strftime('%Y-%m-%d')
        
        for i in range(int(labchemin.text)):

            
            nom=str(tableau[i,0])
            pp=str(tableau[i,2])
            mat=str(tableau[i,3])

            try:
                puu=float(pp)
            except:
                puu=float('0.0')

            try:

                self.cconnexion()
                cursor=con.cursor()
                query="insert into produit(matricule,nom,categorie,anti,traite,posologie,age_utilisation,pu,stock,dats,stock_p) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                datat=(mat,nom,"-","-","-","-","-",puu,0,datt,0)
                cursor.execute(query,datat) 
                con.commit()
                cursor.close()
                con.close()

            except:
               rater +=1

               listiderror.append(mat)
               listnomeror.append(nom)
               listpuerror.append(puu) 

        msg=Popup(title="STATUT CONNEXION",content=Button(text='Les produit importés avec succes'),size_hint=(None, None), size=(400,200))
        msg.open()

        msg=Popup(title="STATUT CONNEXION",content=Button(text='Les produits non enregistrés  :'+ str(rater)),size_hint=(None, None), size=(400,200))
        msg.open()

Importeur().run()