import mysql.connector
from datetime import datetime

class EcoleApp:

    def __init__(self):
        
        pass
    

    def UserAjout(self,v1,v2,gmail,v4,v6,v7,v8,v9,v10,v11,v12,con):
        
        try:
            cursor=con.cursor()
            query="insert into users(id,name,email,email_verified_at,password,remember_token,created_at,updated_at,first_name,last_name,address,phone,file,fonction_id,status,sexe) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,gmail,"0000-00-00",v4,"",datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v6,v7,v8,v9,v10,v11,1,v12)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def UserRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from users where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def UserUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,con):

        try:
            cursor=con.cursor()
            query="update users set name=%s,email=%s,password=%s,updated_at=%s,first_name=%s,last_name=%s,address=%s,phone=%s,file=%s,fonction_id=%s,sexe=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v5,v6,v7,v8,v9,v10,v11,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def UserDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update users set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def TypeTravailAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into type_travails(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa) 
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TypeTravailRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from type_travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TypeTravailUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update type_travails set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TypeTravailDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update type_travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def TravailAjout(self,v1,v2,v3,date1,v4,v5,v6,file,con):

        try:
            cursor=con.cursor()
            query="insert into travails(id,title,description,date_de_remise,cours_id,type_travails_id,annee_id,created_at,updated_at,file,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,date1,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),file,1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TravailRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TravailUpdate(self,v1,v2,v3,date1,v4,v5,v6,file,con):

        try:
            cursor=con.cursor()
            query="update travails set title=%s,description=%s,date_de_remise=%s,cours_id=%s,type_travails_id=%s,annee_id=%s,updated_at=%s,file=%s where id=%s"
            dataa=(v2,v3,date1,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),file,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TravailDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def TrancheAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into tranches(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TrancheRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from tranches where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TrancheUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update tranches set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TrancheDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update tranches set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def SectionAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into sections(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def SectionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from sections where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def SectionUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update sections set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def SectionDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update sections set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def PeriodeAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into periodes(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def PeriodeRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from periodes where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def PeriodeUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update periodes set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def PeriodeDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update periodes set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat




    def PaiementAjout(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,con):
        
        try:
            cursor=con.cursor()
            query="insert into paiements(id,montant,devises_id,motifs_id,eleves_id,classes_id,tranches_id,annee_id,created_at,updated_at,users_id) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,v7,v8,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v9)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def PaiementRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from paiements")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def PaiementUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,con):

        try:
            cursor=con.cursor()
            query="update paiements set montant=%s,devises_id=%s,motifs_id=%s,eleves_id=%s,classes_id=%s,tranches_id=%s,annee_id=%s,updated_at=%s,users_id=%s where id=%s"
            dataa=(float(v2),v3,v4,v5,v6,v7,v8,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v9,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    
    def OptionAjout(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            query="insert into options(id,name,section_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def OptionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from options where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def OptionUpdate(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            query="update options set name=%s,section_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def OptionDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update options set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat




    def MotifAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into motifs(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def MotifRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from motifs where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def MotifUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update motifs set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def MotifDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update motifs set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def InscriptionAjout(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,datenaiss,v12,v13,v14,v15,con):

        try:
            cursor=con.cursor()
            query="insert into inscriptions(id,name,first_name,last_name,ecole_provenance,percent,phone,classes_id,options_id,annee_id,created_at,updated_at,status,date_naissance,lieu_de_naissance,nationalite,nom_parent,postnom_parent) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1,datenaiss,v12,v13,v14,v15)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def InscriptionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from inscriptions where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def InscriptionUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,con):
        try:
            cursor=con.cursor()
            query="update inscriptions set name=%s,first_name=%s,last_name=%s,ecole_provenance=%s,percent=%s,phone=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s,date_naissance=%s,lieu_de_naissance=%s,nationalite=%s,nom_parent=%s,postnom_parent=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v11,v12,v13,v14,v15,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def InscriptionDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update inscriptions set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def HoraireAjout(self,v1,v2,v3,v4,v5,v6,con):

        try:
            cursor=con.cursor()
            query="insert into horaires(id,title,image,classes_id,options_id,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def HoraireRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from horaires where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def HoraireUpdate(self,v1,v2,v3,v4,v5,v6,con):

        try:
            cursor=con.cursor()
            query="update horaires set title=%s,image=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def HoraireDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update horaires set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def FonctionAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into fonctions(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def FonctionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from fonctions where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def FonctionUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update fonctions set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def FonctionDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update fonctions set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def FaireTravailRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from faire_travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def FaireTravailDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update faire_travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def EleveAjout(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="insert into eleves(id,name,first_name,last_name,matricule,description,users_id,classes_id,options_id ,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def EleveRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from eleves where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def ElveUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="update eleves set name=%s,first_name=%s,last_name=%s,matricule=%s,description=%s,users_id=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def EleveDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update eleves set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def DeviseRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from devises where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def DeviseUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update devises set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def DeviseDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update devises set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def DevisetAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into devises(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    



    def CoursEnseignantRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from cour_enseigners")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursEnseignantUpdate(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="update cour_enseigners set cours_id=%s,users_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursEnseignantAjout(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="insert into cour_enseigners(id,cours_id,users_id,annee_id,created_at,updated_at) values(%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat

    def CoursRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from cours where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursUpdate(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="update cours set name=%s,ponderation=%s,classes_id=%s,options_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update cours set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def CoursAjout(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into cours(id,name,ponderation,classes_id,options_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat


    def CommuniqueRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from communiques where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CommuniqueUpdate(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="update communiques set title=%s,content=%s,file=%s,users_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CommuniqueDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update communiques set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def CommuniqueAjout(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into communiques(id,title,content,file,users_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat



    def Anne_ScolaireRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from anne_scolaires where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def AnneSColaireUpdate(self,v1,vdate,v4,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set name=%s,updated_at=%s where id=%s"
            dataa=(v1,vdate,v4)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def AnnScolaireDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def AnneSColaireAjout(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into anne_scolaires(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,int(v5))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    
    def classRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from classes where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
        


    def classAjout(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into classes(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,int(v5))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    
    def classUpdate(self,v1,vdate,v4,con):

        try:
            cursor=con.cursor()
            query="update classes set name=%s,updated_at=%s where id=%s"#,updated_at=%s
            dataa=(v1,vdate,v4)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def classDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update classes set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def connecteBD():

        try:
            con=mysql.connector.connect(
            host="localhost",
            user="askyas",
            password="askyas",
            database="EcolApp"
            )

            return con

        except:
            pass
