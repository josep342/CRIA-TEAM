from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.graphics.vertex_instructions import RoundedRectangle
from kivy.metrics import *
from kivy.graphics import *
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.textfield import MDTextField
from kivy.uix.popup import Popup
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivymd.uix.datatables import MDDataTable
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from datetime import datetime
from kivymd.uix.datatables import MDDataTable
from kivy.uix.image import Image
import random

from back import EcoleApp
import mysql.connector 

#Builder.load_file('screenmanangerr.kv')

class EcolAppApp(MDApp):

    def build(self):

        global etatmenu,pagecurrent,cadresetting1,tabsection,btrengistrersection,tintitulesection,tidsection,titresection

        global tidoption,tintituleoption,btrengistrer,taboption,titreann,tidanne,tintituleanne,btrengistreranne,tabanne
        global cadresettingpaiemnt,cadresettinguser,bmenu
        global cadre,cadsettinghaut,men2,cadreTravauxhaut
        global cadreAccueil,cadreInscription,cadrePaiement2,cadreTravaux,cadreTravaux1,cadreTravaux2,cadreTravaux3,cadreCote
        global jour,mois,ann
        global t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16
        global c1,c2,c3,c4,c5
        global btsave
        global cadreInscription1,cadreInscription2,cadreInscription3,cadreconnexion,cadrePaiement1,cadrePaiement
        global check1,check2,check2A,check1A,triAZ2,triAZ1,checkpaie2,checkpaie1
        global paiec01,paiec1,paiec2,paiec3,paiec4,paiet1,paiet2,paiet3,paiet4
        global trechPaiement,spinPaiement,tabinstance,ititre,tabtravaux
        global cadreCote1,cadreCote2,checkcote1,checkcote2,checkdelib2,checkdelib1

        pagecurrent='accueilPage'

        etatmenu=0
        tabinstance=[]

        #self.theme_cls.primary_palette = "Darkblue"
        #self.theme_cls.theme_style = "Dark"

        # page principal 

        cadre=FloatLayout()
        # la table d outils 
        # cadreAccueil,cadreInscrption


        # les outils de la page de conneion
        cadreconnexion=Builder.load_string('''

FloatLayout:
    pos_hint:{'center_x':0.5,'y':.1}
    size_hint:.8,.8

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
    ''')
        
        lbtitreconn=Builder.load_string('''
Label:
    text: "Connexion"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'y':0.87}
    size_hint:0.9,0.15
    bold:True
             ''')
        imgconn=Builder.load_string('''   
Image:
    source:'admin.png'
    pos_hint:{'center_x':0.5,'y':0.75}
    size_hint:0.15,0.1
''')
        
        tid=Builder.load_string('''
MDTextField:
    id:tid
    hint_text:"Identifiant"
    pos_hint:{'center_x':.5,'y':.6}
    size_hint:.8,.15
    text_color_normal:"black"
    font_size:'20sp'
    icon_right:'account'
    line_color_normal:'black'
''')
        
        tpwd=Builder.load_string('''
MDTextField:
    id:tpwd
    hint_text:"Pwd"
    pos_hint:{'center_x':.5,'y':.4}
    size_hint:.8,.15
    text_color_normal:"black"
    font_size:'20sp'
    icon_right:'eye'
    password:True
    line_color_normal:'black'
''')
        
        btconnexion=Builder.load_string('''
Button:
    text:"Se Connecter"
    pos_hint:{'x':.45,'y':.15}
    size_hint:.5,.06
    text_color_normal:"black"
    color:'white'
    font_size:'20sp'
    bold:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size

            radius:[15]
''')
        btconnexion.bind(on_release=self.openaccueilPage)
        
        try:
            cadreconnexion.add_widget(tid)
            cadreconnexion.add_widget(tpwd)
            cadreconnexion.add_widget(btconnexion)

            cadreconnexion.add_widget(lbtitreconn)
            cadreconnexion.add_widget(imgconn)
        except:
            pass

        # outils de la page d acceuil

        bmenu=Builder.load_string('''
MDTopAppBar:
    title: "EcolApp"
    pos_hint: {'x': 0,'y': 0.92}
    size_hint:1,.08
    left_action_items: [["menu", lambda x: app.affmenugacuhe(self)]]
    right_action_items: [["dots-vertical", lambda x: app.affmenugacuhe(self)]]
                                  
    md_bg_color: [0,0,1,1]
    elevation:4

''')
        # les menue

        men2=Builder.load_string('''
FloatLayout:
    size_hint:.3,.72
    pos_hint:{'x':0,'y':.2}
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        Rectangle:
            size:self.size
            pos:self.pos

''')

        ic1=Builder.load_string('''    
MDIconButton:
    icon:'home'
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.9}
                                
    on_release:app.openacceuil(self)
                                
''')
        ic2=Builder.load_string('''
MDIconButton:
    icon:'file-document'                
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.8}
''')
        ic3=Builder.load_string('''
MDIconButton:
    icon:'bank'
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.7}
''')
        
        ic4=Builder.load_string('''
MDIconButton:
    icon:'book-account'
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.6}
                                
''')
        ic5=Builder.load_string('''
                    
MDIconButton:
    icon:"delete-variant"
    text_color:'blue'
    theme_text_color:'Custom'
    
    pos_hint:{'x':.01,'y':.5}
                                
''')
        ic6=Builder.load_string('''
MDIconButton:
    icon:"comment-alert"
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.4}
''')
        ic7=Builder.load_string('''
MDIconButton:
    icon:"table-chair"
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.3}
                                
''')
        ic8=Builder.load_string('''
                    
MDIconButton:
    icon:"face-agent"
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.2}
                                
''')
        ic9=Builder.load_string('''
MDIconButton:
    icon:"arrange-bring-to-front"
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.1}   
''')
        
        try:
            men2.add_widget(ic1)
            men2.add_widget(ic2)
            men2.add_widget(ic3)
            men2.add_widget(ic4)
            men2.add_widget(ic5)
            men2.add_widget(ic6)
            men2.add_widget(ic7)
            men2.add_widget(ic8)
            men2.add_widget(ic9)
        except:
            pass


        b1=Builder.load_string('''
Button:
    text:"Page Accueil"
    background_normal:''
    pos_hint: {'x':.2,'y': .92}
    size_hint:0.3,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
        b1.bind(on_release=self.openaccueilPage)
                
        b2=Builder.load_string('''
Button:
    text:"Gestion d'Inscriptions"
    background_normal:''
    pos_hint: {'x':.2,'y': .82}
    size_hint:0.5,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
        b2.bind(on_release=self.inscriptionF) 
                
        b3=Builder.load_string('''
Button:
    text:"Gestion de Paiement"
    background_normal:''
    pos_hint: {'x':.2,'y': .72}
    size_hint:0.49,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255

    on_release:app.openPaimentF(self)
    
''')
        b4=Builder.load_string('''        

Button:
    text:"Gestion de Cote"
    background_normal:''
    pos_hint: {'x':.2,'y': .62}
    size_hint:0.38,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
        
        b4.bind(on_release=self.openCotePage)

        b5=Builder.load_string('''

Button:
    text:"Gestion des Travaux"
    background_normal:''
    pos_hint: {'x':.2,'y': .52}
    size_hint:0.5,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255

''')
        b5.bind(on_release=self.openTravauxPage)
            
        b6=Builder.load_string('''
Button:
    text:"Gestion Communicationnelle"
    background_normal:''
    pos_hint: {'x':.2,'y': .42}
    size_hint:0.68,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')

        b7=Builder.load_string('''
Button:
    text:"Gestion des Enseignants"
    background_normal:''
    pos_hint: {'x':.2,'y': .32}
    size_hint:0.6,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
            
        b8=Builder.load_string('''

Button:
    text:"Gestion des Personneles"
    background_normal:''
    pos_hint: {'x':.2,'y': .22}
    size_hint:0.58,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
            

        b9=Builder.load_string('''
Button:
    text:"Gestion des Abonnéss"
    background_normal:''
    pos_hint: {'x':.2,'y': .12}
    size_hint:0.53,0.05
    bold:True
    font_size:'20sp'
    color:'black'
    background_color:202/255,202/255,202/255
''')
        
        try:
            men2.add_widget(b1)
            men2.add_widget(b2)
            men2.add_widget(b3)
            men2.add_widget(b4)
            men2.add_widget(b5)
            men2.add_widget(b6)
            men2.add_widget(b7)
            men2.add_widget(b8)
            men2.add_widget(b9)
        except:
            pass
            

        cadreAccueil=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')
        
        titreacc1=Builder.load_string('''
Label:
    text: " Welcome  "
    bold:True
    color:'black'
    font_size:'30sp'
    pos_hint:{'center_x':0.5,'center_y':0.95}
    size_hint:0.8,0.5
    bold:True
''')
        btsetting=Builder.load_string('''
MDIconButton:
    icon:'book-cog'
    pos_hint:{'x':.9,'y': .9}
    size_hint:.1,.1
    text_color:255/255,128/255,0/255
    theme_text_color:'Custom'
    text_color:'black'

    on_release:app.opensetting(self)
        
''')
        
        try:
            cadreAccueil.add_widget(titreacc1)
            cadreAccueil.add_widget(btsetting) 
        except:
            pass

        # ltes outils de la page d inscrption  

        cadreInscription=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadreInscription1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadrehautInscription=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "Page Inscription"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        ibt1=Builder.load_string('''
Button:
    text:"Ajout"
    bold:True
    pos_hint:{'x':0.28,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt1.bind(on_release=self.openinsertion)
        
        ibt2=Builder.load_string('''
Button:
    text:"Mise à Jour"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.openupdate) 
        
        ibt3=Builder.load_string('''
Button:
    text:"Journal"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.openjournalinscription)
        
        ibt4=Builder.load_string('''
Button:
    text:"Analyse"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        ibt4.bind(on_release=self.openanalyse)
        
        t1=Builder.load_string('''

MDTextField:
    hint_text:'Identifiant'
    pos_hint:{'x':.025,'y': .85}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'spider'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
                               ''')

        t2=Builder.load_string('''
MDTextField:
    hint_text:'Nom'
    pos_hint:{'x':.3,'y': .85}
    size_hint:.3,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        t3=Builder.load_string('''
MDTextField:
    hint_text:'POstnom'
    pos_hint:{'x':.65,'y': .85}
    size_hint:.325,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        t4=Builder.load_string('''

MDTextField:
    hint_text:'Prenom'
    pos_hint:{'x':.025,'y': .75}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')
        t5=Builder.load_string('''
MDTextField:
    hint_text:'Ecole Provenance'
    pos_hint:{'x':.3,'y': .75}
    size_hint:.1,.12
    text_color:255/255,128/255,0/255
    icon_right:'human-edit'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')

        t6=Builder.load_string('''
MDTextField:
    hint_text:'Pourcentage Realisé'
    pos_hint:{'x':.45,'y': .75}
    size_hint:.15,.12
    text_color:255/255,128/255,0/255
    icon_right:'sort-numeric-ascending'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        t7=Builder.load_string('''
MDTextField:
    hint_text:'Phone'
    pos_hint:{'x':.65,'y': .75}
    size_hint:.325,.12
    text_color:255/255,128/255,0/255
    icon_right:'phone'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')

        l1=Builder.load_string('''
Label:
    text:'Joindre le Dossier(*.pdf)'
    pos_hint:{'x':.27,'y': .48}
    size_hint:.1,.1
    font_size:'12sp'
    color:"black"
''')
        f1=Builder.load_string('''
MDIconButton:

    icon:'file'
    pos_hint:{'x':.44,'y': .48}
    size_hint:.05,.1
''')
        l2=Builder.load_string('''
MDIcon:
    icon:'bank'
    pos_hint:{'center_x':.5,'y': .6}
    size_hint:.3,.1
    
        ''')
        t8=Builder.load_string('''
                               

MDTextField:
    hint_text:'Lieu de Naissance'
    pos_hint:{'x':.025,'y': .62}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'spider'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        t9=Builder.load_string('''
MDTextField:
    hint_text:'Nationalité'
    pos_hint:{'x':.275,'y': .62}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        t10=Builder.load_string('''
MDTextField:
    hint_text:'Nom Parent(Tutel)'
    pos_hint:{'x':.525,'y': .62}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        t11=Builder.load_string('''
MDTextField:
    hint_text:'Prenom Parent(Tutel)'
    pos_hint:{'x':.775,'y': .62}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        
        lbnaiss=Label(text="Date de Naissane",pos_hint={'center_x':.5,'center_y':.9},color='black',bold=True,size_hint=(.5,.5))

        annup=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-up'
    pos_hint:{'center_x':.2,'center_y': .7}
    on_release:app.annplus(self)
                                         
        ''')

        ann=Builder.load_string('''
Spinner:
    text:"AAAA"
    color:'red'
    font_size:'15sp'
    pos_hint:{'center_x':.2,'center_y': .4}
    size_hint:.2,.4
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:223/255,223/255,223/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

        
        ''')

        anndown=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-down'
    pos_hint:{'center_x':.2,'center_y': .1}
    on_release:app.annmoins(self)
                                         
        ''')

        ann.bind(on_release=self.chargeAnne)

        moisup=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-up'
    pos_hint:{'center_x':.5,'center_y': .7}
    on_release:app.moisplus(self)
                  
        ''')

        mois=Builder.load_string('''
Spinner:
    text:"MM"
    color:'red'
    font_size:'15sp'
    pos_hint:{'center_x':.5,'center_y': .4}
    size_hint:.2,.4
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:223/255,223/255,223/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

        
        ''')
        mois.bind(on_release=self.chargemois)

        moisdown=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-down'
    pos_hint:{'center_x':.5,'center_y': .1}
    on_release:app.moismoins(self)
                      
        ''')

        jourup=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-up'
    pos_hint:{'center_x':.8,'center_y': .7}
    on_release:app.jourplus(self)

                                                
        ''')

        jour=Builder.load_string('''
Spinner:
    text:"JJ"
    color:'red'
    font_size:'15sp'
    pos_hint:{'center_x':.8,'center_y': .4}
    size_hint:.2,.4
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:223/255,223/255,223/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        
        ''')
        jour.bind(on_release=self.chargejour)

        jourdown=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-down'
    pos_hint:{'center_x':.8,'center_y': .1}
    on_release:app.jourmoins(self)
                      
        ''')

        cadredate=Builder.load_string('''

FloatLayout:   
    pos_hint:{'x':.025,'y': .4}
    size_hint:.2,.15

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
''')
        
        try:
            
            cadredate.add_widget(lbnaiss)
            cadredate.add_widget(ann)
            cadredate.add_widget(mois)
            cadredate.add_widget(jour)

            cadredate.add_widget(anndown)
            cadredate.add_widget(annup)
            cadredate.add_widget(moisdown)
            cadredate.add_widget(moisup)
            cadredate.add_widget(jourdown)
            cadredate.add_widget(jourup)
        except:
            pass 

        ttt=Label(text="Sexe",pos_hint={'x':.26,'y': .42},size_hint=(.04,.04),color='black')

        cc1=Builder.load_string('''
Spinner: 
    text:"Homme"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.375,'y': .42}
    size_hint:.1,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        cc1.bind(on_release=self.chargesexe)

        t14=Builder.load_string('''
MDTextField:
    hint_text:'Mail'
    pos_hint:{'x':.525,'y': .5}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'gmail'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')

        t15=Builder.load_string('''
MDTextField:
    hint_text:'Pwd'
    pos_hint:{'x':.775,'y': .5}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'eye'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        l3=Builder.load_string('''
Label:
    text:"Detail Scolaire"
    bold:True
    pos_hint:{'center_x':.5,'y': .32}
    size_hint:.3,.1
    color:"black"
    font_size:"15sp"
''')
        l4=Builder.load_string('''

Label:
    text:'Option'
    pos_hint:{'x':.3,'y': .208}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        c1=Builder.load_string('''
Spinner: 
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.4,'y': .238}
    size_hint:.13,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        c1.bind(on_release=self.chargeoption)
        c1.bind(text=self.selectOption)

        l5=Builder.load_string('''
Label:
    text:'Section'
    pos_hint:{'x':.05,'y': .208}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        c2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.12,'y': .238}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        c2.bind(on_release=self.chargeSection)
        c2.bind(text=self.selectSection)

        l6=Builder.load_string('''
Label:
    text:'Classe'
    pos_hint:{'x':.6,'y': .208}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
        ''')

        c3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.65,'y': .238}
    size_hint:.1,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')
        c3.bind(on_release=self.chargeClass)
        c3.bind(text=self.selectClass)

        l7=Builder.load_string('''
Label:
    text:'Edition'
    pos_hint:{'x':.775,'y': .208}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        c4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.86,'y': .238}
    size_hint:.1,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')
        c4.bind(on_release=self.chargeEdition)
        c4.bind(text=self.selectEdition)

        l8=Builder.load_string('''
Label:
    text:'Fonction'
    pos_hint:{'x':.775,'y': .328}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        c5=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.86,'y': .348}
    size_hint:.1,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        c5.bind(on_release=self.chargeFonction)
        c5.bind(text=self.selectFonction)

        t16=TextInput(text="Description",pos_hint={'x':.02,'y':.07},size_hint=(.6,.1))
        t16.bind(focus=self.efface)

        btsave=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    text:"[b]Enregistrer[/b]"
    markup:True
    size_hint:(0.16,0.05)
    pos_hint:{'x':0.8,'y':0.06}
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
        ''') 

        btsave.bind(on_release=self.operationinscription)   

    #on_release:app.updateinfoperson(self) 
    #l1,l7,t1-t16,c1-c5,

    #,datenaiss,decription

        try:
            cadreInscription1.add_widget(l1)
            cadreInscription1.add_widget(l2)
            cadreInscription1.add_widget(l3)
            cadreInscription1.add_widget(l4)
            cadreInscription1.add_widget(l5)
            cadreInscription1.add_widget(l6)
            cadreInscription1.add_widget(l7)
            cadreInscription1.add_widget(l8)
        except:
            pass
        try:
            
            cadreInscription1.add_widget(cadredate)
        except:
            pass

        try:
            
            cadreInscription1.add_widget(cc1)
            cadreInscription1.add_widget(c1)
            cadreInscription1.add_widget(c2)
            cadreInscription1.add_widget(c3)
            cadreInscription1.add_widget(c4)
            cadreInscription1.add_widget(c5)
        except:
            pass
        try:
            cadreInscription1.add_widget(t1)
            cadreInscription1.add_widget(t2)
            cadreInscription1.add_widget(t3)
            cadreInscription1.add_widget(t4)
            cadreInscription1.add_widget(t5)
            cadreInscription1.add_widget(t6)
            cadreInscription1.add_widget(t7)
            cadreInscription1.add_widget(t8)
            cadreInscription1.add_widget(t9)
            cadreInscription1.add_widget(t10)
            cadreInscription1.add_widget(t11)
            #cadreInscription.add_widget(t12)
            #cadreInscription.add_widget(t13)
            cadreInscription1.add_widget(t14)
            cadreInscription1.add_widget(t15)
        

        except:
            pass

        try:
            cadreInscription1.add_widget(f1)
            cadreInscription1.add_widget(ttt)
        except:
            pass
        try:
            cadreInscription1.add_widget(t16)
        except:
            pass


        try:
            cadreInscription1.add_widget(btsave)
        except:
            pass
            
        try:
            cadrehautInscription.add_widget(ititre)
            cadrehautInscription.add_widget(ibt1)
            cadrehautInscription.add_widget(ibt2)
            cadrehautInscription.add_widget(ibt3)
            cadrehautInscription.add_widget(ibt4)
        except:
            pass
        try:
            cadreInscription.add_widget(cadrehautInscription)
            cadreInscription.add_widget(cadreInscription1)
        except:
            pass

        # outils de la page journal inscription

        cadreInscription2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        check1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        check2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(check1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(check2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spin1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spin1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spin2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spin2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spin3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spin3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par TravID",color='black',bold=True)

        spin4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ALIAS RELATIONNEL",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="Secton",color="black",bold=True)

        aliack1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="Option",color="black",bold=True)

        aliack2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(aliack1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(aliack2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll3=Label(text="Classe",color="black",bold=True)

        aliack3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll4=Label(text="TravID",color="black",bold=True)

        aliack4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres2.add_widget(ll3)
            cadres2.add_widget(aliack3)
            cadres2.add_widget(ll4)
            cadres2.add_widget(aliack4)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spin4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabjournalinscr=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("ID_Trav",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(25))),
            (("MODIFIE",dp(25)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass


        try:
            
            cadreInscription2.add_widget(cadrejj)
            
            cadreInscription2.add_widget(tabjournalinscr)
        except:
            pass


        # outils de la page analyse

        cadreInscription3=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadredessin=Builder.load_string('''
FloatLayout:
    size_hint:.72,.99
    pos_hint:{'x':.0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        try:
            cadreInscription3.add_widget(cadredessin)
        except:
            pass

        cadrejjA=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':.74,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Simple",color="black",bold=True)

        check1A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifanalyse1(self)
    ''')

        l2=Label(text="Ultra",color="black",bold=True)

        check2A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifanalyse2(self)
    ''')

        try:
            cadresous1A.add_widget(l1)
            cadresous1A.add_widget(check1A)
            cadresous1A.add_widget(l2)
            cadresous1A.add_widget(check2A)
        except:
            pass

        cadresous2A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Diagramme",color='black',bold=True)

        spin1A=Builder.load_string('''
Spinner:
    text:"Baton"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin1A.bind(on_release=self.opendiagramme)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2A.add_widget(l1)
            cadresous2A.add_widget(spin1A)
            cadresous2A.add_widget(btval1)
        except:
            pass
        
        cadresous3A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Equilibreur",color='black',bold=True) 

        spin2A=Builder.load_string('''
Spinner:
    text:"Fixe"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin2A.bind(on_release=self.openaffichage)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3A.add_widget(l2)
            cadresous3A.add_widget(spin2A)
            cadresous3A.add_widget(btval2)
        except:
            pass

        cadresous4A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Lecture",color='black',bold=True)

        spin3A=Builder.load_string('''
Spinner:
    text:"Asynchrone"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size 
            radius:[15]
''')
        
        spin3A.bind(on_release=self.openmodulation)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4A.add_widget(l3)
            cadresous4A.add_widget(spin3A)
            cadresous4A.add_widget(btval3)
        except:
            pass

        cadresous5A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Modulation",color='black',bold=True)

        spin4A=Builder.load_string('''
Spinner:
    text:"Frequence"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15] 
''')
        
        spin4A.bind(on_release=self.openmodulation)
        btval4=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="SETTING",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="Legende",color="black",bold=True)

        aliack1A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="Marquage",color="black",bold=True)

        aliack2A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1A.add_widget(ll1)
            cadres1A.add_widget(aliack1A)
            cadres1A.add_widget(ll2)
            cadres1A.add_widget(aliack2A)
        except:
            pass        

        cadres2A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll3=Label(text="FMI",color="black",bold=True)

        aliack3A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll4=Label(text="ORM",color="black",bold=True)

        aliack4A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres2A.add_widget(ll3)
            cadres2A.add_widget(aliack3A)
            cadres2A.add_widget(ll4)
            cadres2A.add_widget(aliack4A)
        except:
            pass

        try:
            cadresous5A.add_widget(l4)
            cadresous5A.add_widget(spin4A)
            cadresous5A.add_widget(btval4)
        except:
            pass

        try:

            cadrejjA.add_widget(cadresous1A)
            cadrejjA.add_widget(cadresous2A) 

            cadrejjA.add_widget(cadresous3A)
            cadrejjA.add_widget(cadresous4A)
            cadrejjA.add_widget(cadresous5A)

            cadrejjA.add_widget(alias)
            cadrejjA.add_widget(cadres1A) 
            cadrejjA.add_widget(cadres2A)

        except:
            pass

        
        try:
            cadreInscription3.add_widget(cadrejjA)
        except:
            pass

        

        # les outils de la page de paiement 

        

        cadrePaiement=Builder.load_string('''
FloatLayout:

    size_hint:1,.92
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:1,1,1
        
        Rectangle:
            pos:self.pos
            size:self.size
''')

        cadrehautpaiement=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "Page Paiement"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        ibt1=Builder.load_string('''
Button:
    text:"Ajout"
    bold:True
    pos_hint:{'x':0.28,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        
        ibt1.bind(on_release=self.openinsertion)
        
        ibt2=Builder.load_string('''
Button:
    text:"Versement"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.openpaiement)
        
        ibt3=Builder.load_string('''
Button:
    text:"Journal"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.openjournalpaiement)
        
        ibt4=Builder.load_string('''
Button:
    text:"Systeme"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        ibt4.bind(on_release=self.openanalyse)

        # cadre paiement 1

        cadrePaiement1=Builder.load_string('''
FloatLayout:

    size_hint:1,.9
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:1,1,1
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        
        

        paiet1=Builder.load_string('''

MDTextField:
    hint_text:'Identifiant'
    pos_hint:{'x':.025,'y': .85}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'spider'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
                               ''')

        paiet2=Builder.load_string('''
MDTextField:
    hint_text:'Nom'
    pos_hint:{'x':.3,'y': .85}
    size_hint:.3,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        paiet3=Builder.load_string('''
MDTextField:
    hint_text:'POstnom'
    #pos_hint:{'x':.65,'y': .85}
    pos_hint:{'x':.025,'y': .75}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        paiet4=Builder.load_string('''

MDTextField:
    hint_text:'Prenom'
    #pos_hint:{'x':.025,'y': .75}
    pos_hint:{'x':.3,'y': .75}
    size_hint:.3,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')
        
        l01=Builder.load_string('''

Label:
    text:'Sexe'
    pos_hint:{'x':.025,'y': .65}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        paiec01=Builder.load_string('''
Spinner: 
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.1,'y': .67}
    size_hint:.12,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        
        l1=Builder.load_string('''

Label:
    text:'Section'
    pos_hint:{'x':.3,'y': .65}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        paiec1=Builder.load_string('''
Spinner: 
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.45,'y': .67}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        l2=Builder.load_string('''
Label:
    text:'Option'
    pos_hint:{'x':.3,'y': .55}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        paiec2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.45,'y': .57}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

      
        l3=Builder.load_string('''
Label:
    text:'Classe'
    pos_hint:{'x':.3,'y': .45}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
        ''')

        paiec3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.45,'y': .47}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')
      
        l4=Builder.load_string('''
Label:
    text:'Edition'
    pos_hint:{'x':.3,'y': .35}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        paiec4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.45,'y': .37}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        tx=Label(text="DETAIL DU VERSEMENT",color='black',bold=True,font_size="20sp",size_hint=(.1,.1),pos_hint={'center_x':.3,'y':.25})

        tx3=Builder.load_string('''
MDTextField:
    hint_text:'TravID'
    pos_hint:{'x':.4,'y': .15}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        tx2=Builder.load_string('''
MDTextField:
    hint_text:'Montant'
    #pos_hint:{'x':.65,'y': .85}
    pos_hint:{'x':.2,'y': .15}
    size_hint:.18,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        tx1=Builder.load_string('''

MDTextField:
    hint_text:'Date Operation'
    #pos_hint:{'x':.025,'y': .75}
    pos_hint:{'x':.025,'y':.15}
    size_hint:.15,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')
        
    
        btpaye=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    text:"[b]Payer[/b]"
    markup:True
    size_hint:(0.1,0.05)
    pos_hint:{'x':0.5,'y':0.03}
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
        ''') 

        btsave.bind(on_release=self.payerVersement)   

    #on_release:app.updateinfoperson(self) 
    #l1,l7,t1-t16,c1-c5,

    #,datenaiss,decription

        try:
            cadrePaiement1.add_widget(l1)
            cadrePaiement1.add_widget(l2)
            cadrePaiement1.add_widget(l3)
            cadrePaiement1.add_widget(l4)

            cadrePaiement1.add_widget(l01)
           
        except:
            pass
        
        try:
            
            cadrePaiement1.add_widget(paiec01)

            cadrePaiement1.add_widget(paiec1)
            cadrePaiement1.add_widget(paiec2)
            cadrePaiement1.add_widget(paiec3)
            cadrePaiement1.add_widget(paiec4)
            
        except:
            pass
        try:
            cadrePaiement1.add_widget(paiet1)
            cadrePaiement1.add_widget(paiet2)
            cadrePaiement1.add_widget(paiet3)
            cadrePaiement1.add_widget(paiet4)
            
        except:
            pass


        try:
            cadrePaiement1.add_widget(btpaye)
        except:
            pass
            
        try:
            cadrehautpaiement.add_widget(ititre)
            #cadrehautpaiement.add_widget(ibt1)
            cadrehautpaiement.add_widget(ibt2)
            cadrehautpaiement.add_widget(ibt3)
            cadrehautpaiement.add_widget(ibt4)
        except:
            pass

        try:
            cadrePaiement1.add_widget(tx)
            cadrePaiement1.add_widget(tx1)
            cadrePaiement1.add_widget(tx2)
            cadrePaiement1.add_widget(tx3)
        except:
            pass

        try:
            cadrePaiement.add_widget(cadrehautpaiement)
            cadrePaiement.add_widget(cadrePaiement1)
        except:
            pass


        cadreGpaie1=Builder.load_string('''
FloatLayout:
    size_hint:.35,.99
    pos_hint:{'x':.65,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.5,.09
    pos_hint:{'x':.1,'y':.83}
    padding:5
    spacing:5

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')

        trechPaiement=Builder.load_string('''

MDTextField:
    hint_text:'Matricule'
    #pos_hint:{'x':.025,'y': .75}
    pos_hint:{'center_y':.5}
    #size_hint:.3,.9
    text_color:255/255,128/255,0/255
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')

        rechP1=Builder.load_string('''
MDIcon:
    icon:'card-search'
    theme_text_color:'Custom'
    text_color:'red'
    pos_hint:{'center_y':.5}
                                                                         
''')
        
        spinPaiement=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.29,.05
    pos_hint:{'x':.62,'y':.85}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        try:
            cadreGpaie1.add_widget(spinPaiement)
        except:
            pass

        try:
            
            cadresous1A.add_widget(trechPaiement)
            cadresous1A.add_widget(rechP1)
        except:
            pass


        cadresous2A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.65}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Type Paiement",color='black',bold=True)

        spin1A=Builder.load_string('''
Spinner:
    text:"Baton"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin1A.bind(on_release=self.opendiagramme)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2A.add_widget(l1)
            cadresous2A.add_widget(spin1A)
            cadresous2A.add_widget(btval1)
        except:
            pass
        
        cadresous3A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Type Tranche",color='black',bold=True) 

        spin2A=Builder.load_string('''
Spinner:
    text:"Fixe"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin2A.bind(on_release=self.openaffichage)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3A.add_widget(l2)
            cadresous3A.add_widget(spin2A)
            cadresous3A.add_widget(btval2)
        except:
            pass

        cadresous4A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.25}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Structuration",color='black',bold=True)

        spin3A=Builder.load_string('''
Spinner:
    text:"All"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size 
            radius:[15]
''')
        
        spin3A.bind(on_release=self.openmodulation)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4A.add_widget(l3)
            cadresous4A.add_widget(spin3A)
            cadresous4A.add_widget(btval3)
        except:
            pass


        alias=Label(text="SETTING",color='black',bold=True,pos_hint={'center_x':.5,'y':.15},size_hint=(.1,.1))

        az=Label(text="A-Z",color='black',bold=True,pos_hint={'x':.1,'y':.07},size_hint=(.1,.1),font_size='13sp')
        za=Label(text="Z-A",color='black',bold=True,pos_hint={'x':.75,'y':.07},size_hint=(.1,.1),font_size='13sp')

        triAZ1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    pos_hint:{'x':.25,'y':.09}
    size_hint:.05,.05
    on_active:app.triAZF1(self)
    ''')
        
        triic1=Builder.load_string('''
MDIcon:
    icon:'filter'
    size_hint:.05,.05
    pos_hint:{'x':.12,'y':.05}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')
        
        
        triAZ2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    pos_hint:{'x':.9,'y':.09}
    size_hint:.05,.05
    on_active:app.triAZF2(self)
    ''')
        
        triic2=Builder.load_string('''
MDIcon:
    icon:'filter'
    size_hint:.05,.05
    pos_hint:{'x':.77,'y':.05}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')
        
        try:
            cadresous5A.add_widget(l4)
            cadresous5A.add_widget(spin4A)
            cadresous5A.add_widget(btval4)
        except:
            pass

        try:

            cadreGpaie1.add_widget(cadresous1A)
            cadreGpaie1.add_widget(cadresous2A) 

            cadreGpaie1.add_widget(cadresous3A)
            cadreGpaie1.add_widget(cadresous4A)

            cadreGpaie1.add_widget(alias)
            
            cadreGpaie1.add_widget(az)
            cadreGpaie1.add_widget(za)

            cadreGpaie1.add_widget(triAZ1)
            cadreGpaie1.add_widget(triAZ2)  

            cadreGpaie1.add_widget(triic1)
            cadreGpaie1.add_widget(triic2) 

        except:
            pass

        
        try:
            cadrePaiement1.add_widget(cadreGpaie1)
        except:
            pass

        # les optuosld de paiement journal 

        cadrePaiement2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkpaie1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifpaieF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkpaie2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifpaieF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkpaie1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkpaie2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spinpaie1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spinpaie1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spinpaie2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spinpaie2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spinpaie3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spinpaie3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par TravID",color='black',bold=True)

        spinpaie4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ALIAS RELATIONNEL",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="Secton",color="black",bold=True)

        aliackpaie1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="Option",color="black",bold=True)

        aliackpaie2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(aliackpaie1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(aliackpaie2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll3=Label(text="Classe",color="black",bold=True)

        aliackpaie3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll4=Label(text="TravID",color="black",bold=True)

        aliackpaie4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres2.add_widget(ll3)
            cadres2.add_widget(aliackpaie3)
            cadres2.add_widget(ll4)
            cadres2.add_widget(aliackpaie4)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spinpaie4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabpaiejourn=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("ID_Trav",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(25))),
            (("MODIFIE",dp(25)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass

        try:
            
            cadrePaiement2.add_widget(cadrejj)

            cadrePaiement2.add_widget(tabpaiejourn)
        except:
            pass

        # les outils de la page de gestion de cote 
        

        cadreCote=Builder.load_string('''
FloatLayout:

    size_hint:1,.92
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        
        cadrehautCote=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        coteititre=Builder.load_string('''

Label:
    text: "GESTION DE COTE"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        
        coteibt3=Builder.load_string('''
Button:
    text:"Deliberation"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        coteibt3.bind(on_release=self.openseliberationF) 
        
        coteibt4=Builder.load_string('''
Button:
    text:"Analyse"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        coteibt4.bind(on_release=self.openanalysedeliberationF)

        try:
            cadrehautCote.add_widget(coteititre)
            cadrehautCote.add_widget(coteibt3)
            cadrehautCote.add_widget(coteibt4)
        except:
            pass


        cadreCote1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkcote1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifcoteF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkcote2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifcoteF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkcote1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkcote2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spincote1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincote1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spincote2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincote2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spincote3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincote3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par Titul..",color='black',bold=True)

        spincote4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ORDRE",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="Croissant A-Z",color="black",bold=True)

        aliackcote1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="Decroissant Z-A",color="black",bold=True)

        aliackcote2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(aliackcote1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(aliackcote2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.02}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')
        
        l5=Label(text="Trier par Edition",color='black',bold=True)

        spincotee5=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btvall5=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadres2.add_widget(l5)
            cadres2.add_widget(spincotee5)
            cadres2.add_widget(btvall5)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincote4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabcote1=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("ID_Trav",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(25))),
            (("MODIFIE",dp(25)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        bexportExcel=Builder.load_string('''
MDIconButton:
    icon:'file-excel'
    pos_hint:{'x':.8,'y':.01}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')
        bexportPdf=Builder.load_string('''
MDIconButton:
    icon:'file-pdf-box'
    pos_hint:{'x':.9,'y':.01}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass


        try:
            cadreCote1.add_widget(cadrejj)

            cadreCote1.add_widget(bexportExcel)
            cadreCote1.add_widget(bexportPdf)
            cadreCote1.add_widget(tabcote1)

        except:
            pass
        
        try:
            cadreCote.add_widget(cadrehautCote) 
            cadreCote.add_widget(cadreCote1)
        except:
            pass
        
        # les outils de la made de deliberation 

        cadreCote2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkdelib1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifdelib1F(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkdelib2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifdelib2F(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkdelib1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkdelib2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')


        l1=Label(text="Ajouter Section",color='black',bold=True)

        spindelib1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spindelib1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Ajouter Option",color='black',bold=True)

        spindelib2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spindelib2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Ajouter Classe",color='black',bold=True)

        spindelib3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spindelib3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Ajouter Periode",color='black',bold=True)

        spindelib4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        alias=Label(text="CRIA CONGO",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')
        
        img=Image(source="drc.jpg")

        
        try:
            cadres1.add_widget(img)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.02}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')
        
        l5=Label(text="Ajouter Edition",color='black',bold=True)

        spindelib5=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btvall5=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadres2.add_widget(l5)
            cadres2.add_widget(spindelib5)
            cadres2.add_widget(btvall5)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spindelib4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabdelib1=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("ID_Trav",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(25))),
            (("MODIFIE",dp(25)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        bexportExcel=Builder.load_string('''
MDIconButton:
    icon:'file-excel'
    pos_hint:{'x':.8,'y':.01}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')
        bexportPdf=Builder.load_string('''
MDIconButton:
    icon:'file-pdf-box'
    pos_hint:{'x':.9,'y':.01}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass


        try:
            cadreCote2.add_widget(cadrejj) 

            cadreCote2.add_widget(bexportExcel)
            cadreCote2.add_widget(bexportPdf)
            cadreCote2.add_widget(tabdelib1)

        except:
            pass


        # mles outils de la page de travaux

        cadreTravaux=Builder.load_string('''
FloatLayout:

    size_hint:1,.92
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:1,1,1
        
        Rectangle:
            pos:self.pos
            size:self.size
''')

        cadreTravauxhaut=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    spacing:10
    padding:10

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
                    

        
        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ititre=Builder.load_string('''

Label:
    text: "GESTION DES TRAVAUX"
    bold:True
    color:'black'
    font_size:'14sp'
    pos_hint:{'center_x':0.5,'y':0.86}
    size_hint:0.8,0.06
    bold:True
            ''')

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spintv1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spintv1.bind(on_release=self.chargeSection)
        spintv1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval1.bind(on_release=self.afficheSection)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spintv1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spintv2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spintv2.bind(on_release=self.chargeoption)
        spintv2.bind(text=self.selectOption)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval2.bind(on_release=self.afficheOption) 

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spintv2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spintv3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spintv3.bind(on_release=self.chargeClass)
        spintv3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
                                   
    
    ''')
        btval3.bind(on_release=self.afficheClass)

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spintv3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par TravID",color='black',bold=True)

        spintv4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spintv4)
            cadresous5.add_widget(btval4)
        except:
            pass

        
        btajouttravaux=Builder.load_string('''
Button:
    text:"Ajouter"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.2}
    background_color:[0,0,0,0]
    bold:True
    on_release:app.ajouttypetravail(self)

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        btapdatetravaux=Builder.load_string('''
Button:
    text:"Mise à jour"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.1}
    background_color:[0,0,0,0]
    bold:True
                                            
    on_release:app.updatetypetravail(self)

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        tabtravaux=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("TITRE",dp(35))),
            (("CONTENU",dp(35))),
            (("DATE",dp(40))),
            (("COURS",dp(40))),
            (("TYPE",dp(25))),
            (("CLASS ",dp(25))),
            (("OPTION",dp(25))),
            (("SECTION",dp(25))),
            (("EDITION",dp(25)))
            ], row_data=[],size_hint=(0.72,0.88),pos_hint={'x':0.28,'y':0},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous2)
            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)
            

            #cadrejj.add_widget(cadres1) 
            #cadrejj.add_widget(cadres2)
        except:
            pass
        
        try:
            cadrejj.add_widget(ititre) 
            cadrejj.add_widget(btajouttravaux) 
            cadrejj.add_widget(btapdatetravaux)
        except:
            pass

        try:
            cadreTravaux.add_widget(cadrejj)
            cadreTravaux.add_widget(tabtravaux)
            
        except:
            pass

        try:
            cadreTravaux.add_widget(cadreTravauxhaut)
        except:
            pass

        # outils de la page setting prince

        cadresetting1=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        #cadsettinghaut, setlab,setic1,setic2,setic3,setic4,setic5,setic6
        
        cadsettinghaut=Builder.load_string('''

FloatLayout:
    pos_hint:{'x':0,'y':.9}
    size_hint:1,.1

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
''')
        setlab=Builder.load_string('''       
Label:
    text: "Parametres"
    bold:True
    color:'white'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.5}
    size_hint:0.9,0.15
    bold:True
''')
        setic1=Builder.load_string('''
MDIconButton:
    icon:"arrow-left-circle"
    pos_hint:{'x':.02,'center_y':.5}
    text_color:'black'

    on_release:app.retourAccueil(self)
''')
        
        setic2=Builder.load_string('''
MDIconButton:
    icon:"account-edit"
    pos_hint:{'x':.6,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'

    on_release:app.settinguser(self)
''')
        setic3=Builder.load_string('''  
MDIconButton:
    icon:"currency-eur"
    pos_hint:{'x':.65,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'

    on_release:app.settingpaiement(self)
''')
        setic4=Builder.load_string('''
MDIconButton:
    icon:"book-education"
    pos_hint:{'x':.7,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'

    on_release:app.settingprince(self)
''')

        setic5=Builder.load_string('''  
MDIconButton:
    icon:"book-open"
    pos_hint:{'x':.75,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'

    on_release:app.accueilPagef(self)
''')
        
        setic6=Builder.load_string('''
MDIconButton:
    icon:"account-card"
    pos_hint:{'x':.8,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'
                                   
    on_release:app.settingPageUser(self)
''')
        
       
        try:
            cadsettinghaut.add_widget(setic1)
            cadsettinghaut.add_widget(setic2)
            cadsettinghaut.add_widget(setic3)
            cadsettinghaut.add_widget(setic4)
            cadsettinghaut.add_widget(setic5)
            cadsettinghaut.add_widget(setic6)
            cadsettinghaut.add_widget(setlab)
           

        except:
            pass
        
        labpdateclss=Label(text="Update",bold=True,color='black',pos_hint={'x':.85,'y':.93},size_hint=(.1,.07),font_size='12sp')

        cadrebtactivUpdate=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.95,'y':.93}  
                                                                                                           
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
        
''')
        btactivUpdate=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x':.5, 'center_y':.5}
    color_active:'red'
    active:False
    #icon_inactive:'close'
    #icon_inactive_color: "grey"
    #on_active:app.activer(self)

''')
        
        titreoption=Label(text="Option",bold=True,color='black',pos_hint={'x':.15,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidoption=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintituleoption=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrer=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.84}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        taboption=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':0.52},check=True,rows_num=2000,use_pagination=True)
        
        
        titreclass=Label(text="Classe",bold=True,color='black',pos_hint={'x':.15,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidclass=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituleclass=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrerclass=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.35}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        tabclass=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':.02},check=True,rows_num=2000,use_pagination=True)

        #tabtrafic.bind(on_check_press=self.check_rdv)

        titresection=Label(text="Section",bold=True,color='black',pos_hint={'x':.68,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidsection=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintitulesection=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrersection=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.84}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''') 
        
        tabsection=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.52},check=True,rows_num=2000,use_pagination=True)

        titreann=Label(text="Edition Scolaire",bold=True,color='black',pos_hint={'x':.68,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidanne=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituleanne=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistreranne=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.35}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''') 
        
        tabanne=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.02},check=True,rows_num=2000,use_pagination=True)

        try:
            cadrebtactivUpdate.add_widget(btactivUpdate)
        except:
            pass

        try:
            pass
            
            #cadre.add_widget(cadsettinghaut)
            #cadre.add_widget(bmenu)
            
        except:
            pass
    
        try:
            
            cadresetting1.add_widget(labpdateclss)
            cadresetting1.add_widget(cadrebtactivUpdate)
            cadresetting1.add_widget(titreoption)
            cadresetting1.add_widget(tidoption)
            cadresetting1.add_widget(tintituleoption)
            cadresetting1.add_widget(btrengistrer)
            cadresetting1.add_widget(taboption)

            cadresetting1.add_widget(tabsection)
            cadresetting1.add_widget(btrengistrersection)
            cadresetting1.add_widget(tintitulesection)
            cadresetting1.add_widget(tidsection)
            cadresetting1.add_widget(titresection)

            
            cadresetting1.add_widget(tabclass)
            cadresetting1.add_widget(titreclass)
            cadresetting1.add_widget(tidclass)
            cadresetting1.add_widget(tintituleclass)
            cadresetting1.add_widget(btrengistrerclass)

            cadresetting1.add_widget(titreann)
            cadresetting1.add_widget(tidanne)
            cadresetting1.add_widget(tintituleanne)
            cadresetting1.add_widget(btrengistreranne)
            cadresetting1.add_widget(tabanne)
        except:
            pass

        # setting paiement

        cadresettingpaiemnt=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        
        
        titremotif=Label(text="Motif",bold=True,color='black',pos_hint={'x':.15,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidmotif=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintitulemotif=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrermotif=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.84}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        tabmotif=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':0.52},check=True,rows_num=2000,use_pagination=True)
        
        titredevise=Label(text="Devise",bold=True,color='black',pos_hint={'x':.68,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tiddevise=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintituledevise=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrerdevise=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.84}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''') 
        
        tabdevise=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.52},check=True,rows_num=2000,use_pagination=True)


        titretranche=Label(text="Tranche",bold=True,color='black',pos_hint={'x':.15,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidtranche=MDTextField(hint_text='ID',icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituletranche=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        
        btrengistrertrache=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.35}
    size_hint:(0.12,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        tabtranche=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':.02},check=True,rows_num=2000,use_pagination=True)

        try:
            cadresettingpaiemnt.add_widget(tabtranche)
            cadresettingpaiemnt.add_widget(btrengistrertrache)
            cadresettingpaiemnt.add_widget(tintituletranche)
            cadresettingpaiemnt.add_widget(tidtranche)
            cadresettingpaiemnt.add_widget(titretranche)
        
        except:
            pass

        try:
            cadresettingpaiemnt.add_widget(tabdevise)
            cadresettingpaiemnt.add_widget(btrengistrerdevise)
            cadresettingpaiemnt.add_widget(tintituledevise)
            cadresettingpaiemnt.add_widget(tiddevise)
            cadresettingpaiemnt.add_widget(titredevise)
        
        except:
            pass
        try:
            cadresettingpaiemnt.add_widget(titremotif)
            cadresettingpaiemnt.add_widget(tidmotif)
            cadresettingpaiemnt.add_widget(tintitulemotif)
            cadresettingpaiemnt.add_widget(btrengistrermotif)
            cadresettingpaiemnt.add_widget(tabmotif)
        
        except:
            pass
        
        # setting user

        cadresettinguser=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        
        titreuser=Label(text="Users",bold=True,color='black',pos_hint={'center_x':.5,'y':.9},size_hint=(.3,.12),font_size='22sp')
    
        labchangemode=Label(text="Update",bold=True,color='black',pos_hint={'x':.8,'y':.93},size_hint=(.1,.07),font_size='12sp')
        
        cadresuitchmode=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.9,'y':.935}  
                                                                                                           
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
        
''')
        suitchmode=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    active:False
''')

        tiduser=MDTextField(hint_text='Identifiant',font_size='20sp',bold=True,line_color_normal="black",icon_right="qrcode",pos_hint={'x':.025,'y':.83},size_hint=(.2,.08),text_color_normal='black')
        tnomunser=MDTextField(hint_text='Nom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.275,'y':.83},size_hint=(.2,.1),text_color_normal='black')
        tpostnomuser=MDTextField(hint_text='Postnom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.525,'y':.83},size_hint=(.2,.08),text_color_normal='black')
        tprenomuser=MDTextField(hint_text='Prenom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.775,'y':.83},size_hint=(.2,.1),text_color_normal='black')
        
        tadressuser=MDTextField(hint_text='Adresse',font_size='20sp',bold=True,line_color_normal="black",icon_right="home",pos_hint={'x':.025,'y':.73},size_hint=(.2,.1),text_color_normal='black')
        tphonuser=MDTextField(hint_text='Phone',icon_right='phone',font_size='20sp',line_color_normal='black',pos_hint={'x':.275,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        tgmailuser=MDTextField(hint_text='E-mail',font_size='20sp',bold=True,line_color_normal="black",icon_right="gmail",pos_hint={'x':.525,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        tpwduser=MDTextField(hint_text='Pwd',icon_right='eye',font_size='20sp',line_color_normal='black',pos_hint={'x':.775,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        
        tintituleclass=MDTextField(hint_text='',font_size='20sp',bold=True,line_color_normal="black",icon_right="gmail",pos_hint={'x':.65,'y':.6},size_hint=(.2,.08),text_color_normal='black')
        
        labfontion=Label(text="Fonction",color='black',pos_hint={'x':.025,'y':.61},size_hint=(.1,.1))
        
        fonctionuser=Builder.load_string('''
Spinner:
    text:"Choisir"
    bold:True
    pos_hint:{'x':.13,'y':.63}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    color:'black'                                                       
                                                                
    canvas.before:
        Color:
            rgb:255/255,128/255,0/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')

        lablph=Label(text="Photo",color='black',pos_hint={'x':.3,'y':.61},size_hint=(.1,.1))

        photonuser=Builder.load_string('''
Spinner:
    text:"Importer fichier"
    color:'black'
    bold:True
    pos_hint:{'x':.45,'y':.63}
    size_hint:.2,.04
    background_color:[0,0,0,0]
                                         
    canvas.before:
        Color:
            rgb:255/255,128/255,0/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')

        btrengistreruser=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.7,'y':0.63}
    size_hint:(0.2,0.04)
    markup:True
    text:"[b]Sauver[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    #on_release:app.deletetheme(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
                                                 
''')
        
        tabuser=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NOM",dp(35)),
            ("POSTNOM ",dp(35)),
            ("PRENOM",dp(35)),
            ("ADRESSE",dp(40)),
            ("PHONE",dp(35)),
            ("PHOTO",dp(35)),
            ("FONCTION",dp(35)),
            ("E-MAIL ",dp(35)),
            ("PWD",dp(35))
            ], row_data=[],size_hint=(0.95,0.54),pos_hint={'x':0.025,'y':0.025},check=True,rows_num=2000,use_pagination=True)
        
        
        try:
            
            cadresuitchmode.add_widget(suitchmode)
            cadresettinguser.add_widget(cadresuitchmode)
            cadresettinguser.add_widget(labchangemode)
        except:
            pass


        try:
            cadresettinguser.add_widget(tabuser)
            cadresettinguser.add_widget(btrengistreruser)
            cadresettinguser.add_widget(photonuser)
            cadresettinguser.add_widget(lablph)
            cadresettinguser.add_widget(fonctionuser)
            cadresettinguser.add_widget(labfontion)
        except:
            pass

        try:
            cadresettinguser.add_widget(titreuser)
            cadresettinguser.add_widget(tpwduser)
            cadresettinguser.add_widget(tgmailuser)
            cadresettinguser.add_widget(tphonuser)
            cadresettinguser.add_widget(tadressuser)
            cadresettinguser.add_widget(tprenomuser)  
            cadresettinguser.add_widget(tpostnomuser)

            cadresettinguser.add_widget(tnomunser)
            cadresettinguser.add_widget(tiduser)
        except:
            pass

        
        try:
            #cadre.add_widget(cadreInscription) 
            cadre.add_widget(cadreconnexion)

        except:
            pass
            
        return cadre


    def verifdelib1F(self,instance):

        if instance.active==True:

            checkdelib2.active=False

    def verifdelib2F(self,instance):

        if instance.active==True:

            checkdelib1.active=False
    
    def verifcoteF1(self,instance):

        if instance.active==True:

            checkcote2.active=False  

    def verifcoteF2(self,instance):

        if instance.active==True:
            
            checkcote1.active=False

    def openseliberationF(self,instance):

        try:
            cadreCote.remove_widget(cadreCote1)
        except:
            pass

        try:
            cadreCote.add_widget(cadreCote2)
        except:
            pass

    def openanalysedeliberationF(self,instance):
        
        try:
            cadreCote.add_widget(cadreCote1)
        except:
            pass

        try:
            cadreCote.remove_widget(cadreCote2)
        except:
            pass

    
    def afficheClass(self,instance):
        global idclass,idoption,idsection

        tabtravaux.row_data=[]
        
        req=EcoleApp()

        ccon=self.connecteBD()

        res=req.TravailRechercheIntIdClass(idsection,idoption,idclass,ccon)

        if res:
            tabtravaux.row_data=res[1]

        
    def afficheOption(self,instance):
        global idclass,idoption,idsection

        tabtravaux.row_data=[]

        req=EcoleApp()

        ccon=self.connecteBD()

        res=req.TravailRechercheIntIdOption(idsection,idoption,ccon)

        if res:
            tabtravaux.row_data=res[1]
        

    def afficheSection(self,instance):
        global idclass,idoption,idsection

        tabtravaux.row_data=[]

        idsection=int(idsection)

        req=EcoleApp()

        ccon=self.connecteBD()

        res=req.TravailRechercheIntIdSection(idsection,ccon)

        if res:
            tabtravaux.row_data=res[1]


    def updatetypetravail(self,instance):
        global ttravupdate,tablup
        
        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''

MDChip:
    background_color:[0,0,0,0]
    text:"[b]Close[/b]"
    markup:True
    pos_hint:{'x':0.75, 'y':.8}
    size_hint:(0.2,0.1)
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True

    MDIcon:
        icon:"close-box"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'  
    #on_release:app.fermerclossettinf(self)
                                                
   
''')
        btvalquestion2.bind(on_release=lambda x:msginforeab.dismiss())

        btupdate=Builder.load_string('''

Button:
    text:"Sauver."
    color:'white'
    pos_hint:{'x':.5,'y': .8}
    size_hint:.2,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        btupdate.bind(on_release=self.updatetravail)

        
        ttravupdate=MDTextField(hint_text='Intitulé(Pas d espace)',pos_hint={'x':.05,'y':.8},size_hint=(.4,.15),line_color_normal='black')
        

        try:
            req=EcoleApp()

            ccon=self.connecteBD()

            res=req.TypeTravailRecherche(ccon)

            tabva=[]

            if res:

                tabva=res[1]

        except:
            pass

        tablup=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NAME",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35)),
            ("ETAT",dp(40))
            ], row_data=tabva,size_hint=(0.9,0.7),pos_hint={'center_x':0.5,'y':.03},check=True,rows_num=2000,use_pagination=True)
        tablup.bind(on_check_press=self.selectelement)

        try:
            cad.add_widget(tablup)
            
            cad.add_widget(btvalquestion2)
            cad.add_widget(ttravupdate)
            cad.add_widget(btupdate)
        except:
            pass


        msginforeab=Popup(title='MISE A JOUR',content=cad,size_hint=(.4,.5))
        msginforeab.open()

    def ajouttypetravail(self,instance):
        global ttrav,tabltype

        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''

MDChip:
    background_color:[0,0,0,0]
    text:"[b]Close[/b]"
    markup:True
    pos_hint:{'x':0.75, 'y':.8}
    size_hint:(0.2,0.1)
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True

    MDIcon:
        icon:"close-box"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'  
    #on_release:app.fermerclossettinf(self)
                                                
   
''')
        btvalquestion2.bind(on_release=lambda x:msginforeab.dismiss())

        btsauver=Builder.load_string('''

Button:
    text:"Sauver."
    color:'white'
    pos_hint:{'x':.5,'y': .8}
    size_hint:.2,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        btsauver.bind(on_release=self.savetypetravail)

        
        ttrav=MDTextField(hint_text='Intitulé(Pas d espace)',pos_hint={'x':.05,'y':.8},size_hint=(.4,.15),line_color_normal='black')
        
        tabltype=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NAME",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35)),
            ("ETAT",dp(40))
            ], row_data=[],size_hint=(0.9,0.7),pos_hint={'center_x':0.5,'y':.03},check=True,rows_num=2000,use_pagination=True)
        
        
        
        try:
            cad.add_widget(tabltype)
            
            cad.add_widget(btvalquestion2)
            cad.add_widget(ttrav)
            cad.add_widget(btsauver)
        except:
            pass


        msginforeab=Popup(title='MISE A JOUR',content=cad,size_hint=(.4,.5))
        msginforeab.open()
    
    def selectelement(self,instance_table,current_row):
        global ttravupdate,idsel
    
        idsel=int(current_row[0])
        ttravupdate.text=str(current_row[1])

    def updatetravail(self,instance):
        global idsel,ttravupdate,tablup

        bt=Builder.load_string('''
Button:
    size_hint:.9,.7
    color:'black'
    bold:True
                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
''')

        try:

            req=EcoleApp()

            ccon=self.connecteBD()

            res=req.TypeTravailUpdate(idsel,ttravupdate.text,ccon)

            if res==True:

                tabval=[]

                ccon=self.connecteBD()

                res=req.TypeTravailRecherche(ccon)

                if res:

                    tabval=res[1]

                    tablup.row_data=tabval

                bt.text="Effectué !!"

                msg=Popup(title="SYSTEME",content=bt,size_hint=(.4,.2))
                msg.open()
            
        except:

            bt.text="EROOR"

            msg=Popup(title="SYSTEME",content=bt,size_hint=(.4,.2))
            msg.open()

    def savetypetravail(self,instance):
        global ttrav,tabltype

        try:
            req=EcoleApp()

            ccon=self.connecteBD()

            res1=req.TypeTravailAjout(random.randint(0,100),ttrav.text,ccon)

            if res1==True:

                ccon=self.connecteBD()

                res=req.TypeTravailRecherche(ccon)

                tabva=[]

                if res:

                    tabva=res[1]

                    ttrav.text=""
                
                tabltype.row_data=tabva

        except:
            pass

    def opendevoir(self,instance):
                
        try:
            cadreTravaux.add_widget(cadreTravaux1)

            cadreTravaux.remove_widget(cadreTravaux2)
            cadreTravaux.remove_widget(cadreTravaux3)

        except:
            pass
    
    def openinterro(self,instance):
                
        try:
            cadreTravaux.add_widget(cadreTravaux2)

            cadreTravaux.remove_widget(cadreTravaux1)
            cadreTravaux.remove_widget(cadreTravaux3)

        except:
            pass

    def openexamen(self,instance):

        try:
            cadreTravaux.add_widget(cadreTravaux3)

            cadreTravaux.remove_widget(cadreTravaux2)
            cadreTravaux.remove_widget(cadreTravaux1)

        except:
            pass

    def openjournalpaiement(self,instance):

        try:
            cadrePaiement.add_widget(cadrePaiement2)
        except:
            pass

        try:
            cadrePaiement.remove_widget(cadrePaiement1)
        except:
            pass


    def openpaiement(self,instance):

        try:
            cadrePaiement.remove_widget(cadrePaiement2)
        except:
            pass

        try:
            cadrePaiement.add_widget(cadrePaiement1)
        except:
            pass

    def verifpaieF1(self,instance):

        if instance.active==True:

            checkpaie2.active=False

    def verifpaieF2(self,instance):

        if instance.active==True:

            checkpaie1.active=False


    def triAZF1(self,instance):

        if instance.active==True:

            triAZ2.active=False
    
    def triAZF2(self,instance):

        if instance.active==True:

            triAZ1.active=False
    
    def openaccueilPage(self,instance):

        # venant de page de connexion

        try:
            cadre.add_widget(cadreAccueil)
        except:
            pass

        try:
             
            cadre.add_widget(bmenu)

        except:
            pass

        try:
            cadre.remove_widget(cadreconnexion)
        except:
            pass
    
        # en etant dans le programme 

        try:
            cadre.remove_widget(men2)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreInscription) 
        except:
            pass

        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass


        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass


    def inscriptionF(self,instance):

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.add_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass

    def openPaimentF(self,instance):
        

        try:
            cadre.add_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass
    
    def openCotePage(self,instance):

        try:
            cadre.add_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

    def openTravauxPage(self,instance):
        global tabinstance,tabval

        try:
            cadre.add_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        
        for li in tabinstance:

            try:
                cadreTravauxhaut.remove_widget(li)
            except:
                pass
        
        tabinstance=[]

        try:
            req=EcoleApp()

            ccon=self.connecteBD()

            res=req.TypeTravailRecherche(ccon)

        except:
            msg=Popup(title='EROOR',content=Button(text="Error !!"),size_hint=(.4,.3))
            msg.open()
        
        tabval=[]

        if res:
            tabval=res[1]

            for lig in tabval:

                a,b,c,d,e=lig

                tt=str(b)

                b=Builder.load_string('''
Button:
    bold:True
    size_hint:.15,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
                
                b.text=str(tt)
                b.bind(on_release=self.opentypeTravailF)

                tabinstance.append(b)

                try:
                    cadreTravauxhaut.add_widget(b)
                except:
                    pass

    
    def opentypeTravailF(self,instance):

        global ititre,tabval,idtypeval

        ititre.text=instance.text

        rep=[lig for lig in tabval if lig[1]==instance.text ]

        for lign  in rep:
            a,b,c,d,e=lign

            idtypeval=int(a)

            print(idtypeval)
       

    def deconnexion(self,instance):

        try:
                
            cadre.add_widget(cadreconnexion)

            cadre.remove_widget(cadreAccueil)
            cadre.remove_widget(bmenu)
        
        except:
            pass

    def opendiagramme(self,instance):
        instance.values=""

        try:
            lisv=['Baton','Circulaire']

            for i in lisv:
                instance.values.append(i)
        except:
            pass

    def openaffichage(self,instance):
        instance.values=""

        try:
            lisv=['Dynamique','Fixe']

            for i in lisv:
                instance.values.append(i)
        except:
            pass
        
    def openlecturesyncho(self,instance):
        instance.values=""

        try:
            lisv=['Synchrone','Asynchrone']

            for i in lisv:
                instance.values.append(i)
        except:
            pass

    def openmodulation(self,instance):

        instance.values=""

        try:
            lisv=['Frequence','Amplitude']

            for i in lisv:
                instance.values.append(i)
        except:
            pass
    
    def verifanalyse1(self,instance):
        if instance.active==True:
            check2A.active=False
    
    def verifanalyse2(self,instance):
        if instance.active==True:
            check1A.active=False
            
    def verif1(self,instance):
        if instance.active==True:
            check2.active=False
    
    def verif2(self,instance):
        if instance.active==True:
            check1.active=False

    def chargeClass(self,instance): 
        
        global tabvalClass

        instance.values=""
        requete=EcoleApp()
        ccon=self.connecteBD()

        listval=requete.classRecherche(ccon)

        tabvalClass=listval[1]

        for lig in tabvalClass:
            a,b,c,d,e=lig

            instance.values.append(b)


    def selectClass(self,instance,text):

        global tabvalClass,idclass

        res=[lig for lig in tabvalClass if lig[1]==instance.text]

        for li in res:
            a,b,c,d,e=li

        idclass=int(a)

        

    def chargeFonction(self,instance):
        
        global tabvalFonction

        instance.values=""
        requete=EcoleApp()
        ccon=self.connecteBD()

        listval=requete.FonctionRecherche(ccon)

        tabvalFonction=listval[1]

        for lig in tabvalFonction:
            a,b,c,d,e=lig

            instance.values.append(b)


    def selectFonction(self,instance,text):

        global tabvalFonction,idfonction

        res=[lig for lig in tabvalFonction if lig[1]==instance.text]

        for li in res:
            a,b,c,d,e=li

        idfonction=int(a)

        


    def chargeEdition(self,instance):
        
        global tabvalEdition

        instance.values=""
        requete=EcoleApp()
        ccon=self.connecteBD()

        listval=requete.Anne_ScolaireRecherche(ccon)

        tabvalEdition=listval[1]

        for lig in tabvalEdition:
            a,b,c,d,e=lig

            instance.values.append(b)


    def selectEdition(self,instance,text):

        global tabvalEdition,idEdition

        res=[lig for lig in tabvalEdition if lig[1]==instance.text]

        for li in res:
            a,b,c,d,e=li

        idEdition=int(a)


    def chargeSection(self,instance): 
        
        global tabvalSection

        instance.values=""
        requete=EcoleApp()
        ccon=self.connecteBD()

        listval=requete.SectionRecherche(ccon)

        tabvalSection=listval[1]

        for lig in tabvalSection:
            a,b,c,d,e=lig

            instance.values.append(b)


    def selectSection(self,instance,text):

        global tabvalSection,idsection

        res=[lig for lig in tabvalSection if lig[1]==instance.text]

        for li in res:
            a,b,c,d,e=li

        idsection=int(a)
        
    
    def selectOption(self,instance,text):
        global tabvalOption,idoption

        res=[lig for lig in tabvalOption if lig[1]==instance.text]

        for li in res:
            a,b,c,d,e,f=li

        idoption=int(a)

    def chargeoption(self,instance):
        global tabvalOption

        instance.values=""
        requete=EcoleApp()
        ccon=self.connecteBD()

        listval=requete.OptionRecherche(ccon)

        tabvalOption=listval[1]

        for lig in tabvalOption:
            a,b,c,d,e,f=lig

            instance.values.append(b)

    def chargesexe(self,instance):

        instance.values=""

        listS=['Home','Femme'] 

        for i in range(len(listS)):
            instance.values.append(listS[i]) 

    def efface(self,instance,value):

        instance.text=""

    def jourmoins(self,instance):

        try:
            if int(jour.text)>1:

                jour.text=str(int(jour.text)-1)
        except:
            pass

    def jourplus(self,instance):

        if int(jour.text)<31:
            try:
                jour.text=str(int(jour.text)+1)
            except:
                pass

    def moismoins(self,instance):

        try:
            if int(mois.text)>1:

                mois.text=str(int(mois.text)-1)
        except:
            pass
    
    def moisplus(self,instance):
            
        try:
            if int(mois.text)<12:
                mois.text=str(int(mois.text)+1)
        except:
            pass

    def annmoins(self,instance):
        try:
            ann.text=str(int(ann.text)-1)
        except:
            pass
    
    def annplus(self,instance):
    
        try:
            ann.text=str(int(ann.text)+1)
        except:
            pass 

    def chargejour(self,instance):
        instance.values=""

        for i in range(32):

            instance.values.append(str(i))
    
    def chargemois(self,instance):

        instance.values=""

        for i in range(13):
            
            instance.values.append(str(i))

    def chargeAnne(self,instance):

        instance.values=""

        for i in range(2005,2020):
            
            instance.values.append(str(i))

    
    def openacceuil(self,instance):

        try:
            cadre.add_widget(cadreAccueil)
        except:
            pass
        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
    def operationinscription(self,instance):
            
        if instance.text=="Enregistrer":

            datee=ann.text+"-"+mois.text+"-"+jour.text

            t16.text="Description"

            bd=EcoleApp()

            ccon=self.connecteBD()

            if ccon:
            
                req=bd.InscriptionAjout(int(t1.text),t2.text,t3.text,t4.text,t5.text,t6.text,t7.text,idclass,idoption,idEdition,datetime.strptime(datee,'%Y-%m-%d'),t8.text,t9.text,t10.text,t11.text,ccon)
                
                print(req)
        else:
            pass


    def openinsertion(self,instance):
        global idclass,idoption,idEdition

        btsave.text="[b]Enregistrer[/b]"

        try:
            cadreInscription.add_widget(cadreInscription1)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription2)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription3)
        except:
            pass

    
    def payerVersement(self,instance):

        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
        
    ''')
        
        btvalquestion2=Builder.load_string('''

MDChip:
    background_color:[0,0,0,0]
    text:"[b]Close[/b]"
    markup:True
    pos_hint:{'x':0.6, 'y':.05}
    size_hint:(0.3,0.12)
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True
    
    MDIcon:
        icon:"close-box"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'                                              
   
''')
        btvalquestion2.bind(on_release=lambda x:msg.dismiss())

        btpayer=Builder.load_string('''

Button:
    text:"Confirmer"
    color:'white'
    pos_hint:{'x':.65,'y': .7}
    size_hint:.3,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        btpayer.bind(on_release=self.chargeSection)

        tdetail=Label(text="NET : "+" 50000 USD",pos_hint={'center_x':.5,'center_y':.5},size_hint=(.3,.1),color='black',bold=True)

        try:
            cad.add_widget(tdetail)
            cad.add_widget(btpayer)
            
            cad.add_widget(btvalquestion2)
            
        except:
            pass

        msg=Popup(title="PAIEMENT SCOLAIRE",content=cad,size_hint=(.4,.5))
        msg.open()


    def openupdate(self,instance):
        global msginforeab

        btsave.text="[b]Modifier[/b]"

        try:
            cadreInscription.add_widget(cadreInscription1)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription2)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription3)
        except:
            pass


        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''

MDChip:
    background_color:[0,0,0,0]
    text:"[b]Close[/b]"
    markup:True
    pos_hint:{'x':0.6, 'y':.05}
    size_hint:(0.3,0.12)
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True
    

    #on_release:app.updateinfoperson(self) 

    MDIcon:
        icon:"close-box"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'  
    #on_release:app.fermerclossettinf(self)
                                                
   
''')
        btvalquestion2.bind(on_release=lambda x:msginforeab.dismiss())

        section=Builder.load_string('''

Spinner:
    text:"Section"
    color:'white'
    pos_hint:{'x':.07,'center_y': .7}
    size_hint:.25,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        section.bind(on_release=self.chargeSection)

        option=Builder.load_string('''

Spinner:
    text:"Option"
    color:'white'
    pos_hint:{'x':.37,'center_y': .7}
    size_hint:.25,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        option.bind(on_release=self.chargeoption)

        classe=Builder.load_string('''

Spinner:
    text:"Classe"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.7,'center_y': .7}
    size_hint:.25,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        classe.bind(on_release=self.chargeClass)

        trech=MDTextField(hint_text='Rechercher par ID',pos_hint={'x':.05,'center_y':.4},size_hint=(.4,.15),line_color_normal='black')
        
        comborech=Builder.load_string('''

Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.5,'center_y': .4}
    size_hint:.45,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]


''')
        try:
            cad.add_widget(classe)
            cad.add_widget(option)
            cad.add_widget(section)
            
            cad.add_widget(btvalquestion2)
            cad.add_widget(trech)
            cad.add_widget(comborech)
        except:
            pass


        msginforeab=Popup(title='RECHERCHE',content=cad,size_hint=(.4,.5))
        msginforeab.open()


    def openjournalinscription(self,instance):

        try:
            cadreInscription.add_widget(cadreInscription2)
        except:
            pass

        try:
            cadreInscription.remove_widget(cadreInscription1)
        except:
            pass

        try:
            cadreInscription.remove_widget(cadreInscription3)
        except:
            pass


    def openanalyse(self,instance):

        try:
            cadreInscription.add_widget(cadreInscription3)
        except:
            pass

        try:
            cadreInscription.remove_widget(cadreInscription1)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription2)
        except:
            pass

    def on_start(self):

        try:
            #self.root.ids.cadregauche.parent.remove_widget(self.root.ids.cadregauche)
            etatmenu=1
        except:
            pass
    
    def retourAccueil(self,instance):
        
        try:
            cadre.add_widget(bmenu)
        except:
            pass
        try:
            cadre.add_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
            cadre.remove_widget(cadresettingpaiemnt)
        except:
            pass

        try:
           
            cadre.remove_widget(cadresettinguser)
        except:
            pass

        try:
           
            cadre.remove_widget(cadsettinghaut)
        except:
            pass

    def opensetting(self,instance):
        try:
            cadre.remove_widget(bmenu)
        except:
            pass
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.add_widget(cadresetting1)
        except:
            pass

        try:
           
            cadre.add_widget(cadsettinghaut)
        except:
            pass

    def settinguser(self, instance):

        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
            cadre.remove_widget(cadresettingpaiemnt)
        except:
            pass

        try:
           
            cadre.add_widget(cadresettinguser)
        except:
            pass

    def settingprince(self,instance):

        try:
            cadre.remove_widget(cadresettingpaiemnt)
        except:
            pass

        try:
            cadre.remove_widget(cadresettinguser)
        except:
            pass

        try:
            cadre.add_widget(cadresetting1)
        except:
            pass
    

    def settingpaiement(self,instance): 

        try:
           
            cadre.remove_widget(cadresettinguser)
        except:
            pass

        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
           
            cadre.add_widget(cadresettingpaiemnt)
    
        except:
            pass

    
    def affmenugacuhe(self,instance):
        global etatmenu

        if etatmenu==0:

            #men2.size_hint=(.3,.8)
            try:
                cadre.add_widget(men2)
            except:
                pass
            

            etatmenu=1
        else:
            #men2.size_hint=(0,0)

            try:
                cadre.remove_widget(men2)
            except:
                pass

            etatmenu=0

        pass
    
    def affmenu(self, instance):
        pass
    
    def connecteBD(self):

        try:
            con=mysql.connector.connect(
            host="localhost",
            user="askyas",
            password="askyas",
            database="EcolApp"
            )

            return con

        except:
            pass

if __name__=="__main__":

    EcolAppApp().run()